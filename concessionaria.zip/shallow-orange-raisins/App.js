import React from 'react';
import { View, Text } from 'react-native';

export default function Concessionaria() {
  const carrosNovos = [
    {
      cor: 'Azul',
      portas: 4,
      potencia: '1.4',
      valor: 50000,
    },
    {
      cor: 'Vermelho',
      portas: 2,
      potencia: '1.6',
      valor: 60000,
    },
    // Adicione mais carros novos aqui...
  ];

  const carrosUsados = [
    {
      ano: 2018,
      cor: 'Prata',
      portas: 4,
      potencia: '1.8',
      valor: 40000,
    },
    {
      ano: 2017,
      cor: 'Preto',
      portas: 2,
      potencia: '2.0',
      valor: 35000,
    },
    // Adicione mais carros usados aqui...
  ];

  return (
    <View>
      <Text>Carros Novos:</Text>
      {carrosNovos.map((carro, index) => (
        <View key={index}>
          <Text>Cor: {carro.cor}</Text>
          <Text>Portas: {carro.portas}</Text>
          <Text>Potência: {carro.potencia}</Text>
          <Text>Valor: R${carro.valor}</Text>
          <Text>-----------------</Text>
        </View>
      ))}

      <Text>Carros Usados:</Text>
      {carrosUsados.map((carro, index) => (
        <View key={index}>
          <Text>Ano: {carro.ano}</Text>
          <Text>Cor: {carro.cor}</Text>
          <Text>Portas: {carro.portas}</Text>
          <Text>Potência: {carro.potencia}</Text>
          <Text>Valor: R${carro.valor}</Text>
          <Text>-----------------</Text>
        </View>
      ))}
    </View>
  );
}
