import React from 'react';
import { View, Text } from 'react-native';

export default function GerenciamentoEscolar() {
  const alunos = [
    {
      nome: 'João',
      turma: 'A',
      professor: 'Maria',
      notas: [8, 7, 6, 9],
    },
    {
      nome: 'Maria',
      turma: 'B',
      professor: 'João',
      notas: [7, 5, 6, 4],
    },
    // Adicione mais alunos aqui...
  ];

  return (
    <View>
      {alunos.map((aluno, index) => (
        <View key={index}>
          <Text>Nome: {aluno.nome}</Text>
          <Text>Turma: {aluno.turma}</Text>
          <Text>Professor: {aluno.professor}</Text>
          <Text>Notas: {aluno.notas.join(', ')}</Text>
          <Text>Situação: {calcularSituacao(aluno.notas)}</Text>
          <Text>-----------------</Text>
        </View>
      ))}
    </View>
  );
}

function calcularSituacao(notas) {
  const media = notas.reduce((acc, nota) => acc + nota, 0) / notas.length;

  if (media >= 6) {
    return 'Aprovado';
  } else if (media >= 4) {
    return 'Recuperação';
  } else {
    return 'Reprovado';
  }
}
